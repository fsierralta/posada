import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function FormularioPago({ auth, flash, dataPago }) {
  const { posada, huespede, fpago, fichaRegistroHuespe, montoPagar } = dataPago;
  const { data, setData, errors, post, processing } = useForm({
    posada_id: posada.id,
    nroficha: fichaRegistroHuespe.nroficha,
    fechaEntrada: fichaRegistroHuespe.fechaEntrada,
    fechaSalida: fichaRegistroHuespe.fechaSalida,
    formaPago_id: fpago[5].id,
    monto: parseFloat(montoPagar) === 0 ? 0 : parseFloat(montoPagar),
    referencia: "",
    observacion: "",
    huespede_id: huespede.id
  });
  const onsubmit = (e) => {
    e.preventDefault();
    post(route("registrohuespedepago.store"), {
      onBefore: (e2) => window.confirm(`Desea enviar este pago:${data.monto}`),
      onError: (error) => console.log("Ha Ocurrido este Error:" + error)
    });
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: "Registro Pago",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Pago" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
            Link,
            {
              className: "bg-slate-500 rounded-lg gap-2 text-white px-4 py-2 items-center",
              href: route("dashboard"),
              children: "Regresar"
            }
          ) }),
          /* @__PURE__ */ jsxs("form", { onSubmit: onsubmit, name: "frmpago", children: [
            /* @__PURE__ */ jsxs("div", { className: "flex space-x-2 ", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "posada",
                    value: "Cabaña"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "posada",
                    defaultValue: posada.nombre,
                    disabled: true
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "ficharegistro",
                    value: "Nro Ficha"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "nroficha",
                    defaultValue: `${fichaRegistroHuespe.nroficha}`,
                    disabled: true,
                    className: "w-full"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full block", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "cedula",
                    value: "cedula"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "cedula",
                    defaultValue: `${huespede.nacionalidad}-${huespede.cedula}`,
                    disabled: true,
                    className: "w-full"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full block", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "huespede",
                    value: "Huespede"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "huesde",
                    defaultValue: `${huespede.nombre} ${huespede.apellidos}`,
                    disabled: true,
                    className: "w-full"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex space-x-2 mt-2 ", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "fechaEntrada",
                    value: "Fecha Entrada"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "fechaEntrada",
                    type: "date",
                    defaultValue: fichaRegistroHuespe.fechaEntrada,
                    disabled: true
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "fechaSalida",
                    value: "Fecha Salida"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "fechaSalida",
                    type: "date",
                    defaultValue: fichaRegistroHuespe.fechaEntrada,
                    disabled: true
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex  space-x-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full block", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "formapago",
                    value: "Forma de pago"
                  }
                ),
                /* @__PURE__ */ jsx(
                  "select",
                  {
                    name: "pago_id",
                    className: "rounded-lg w-full",
                    value: data.formaPago_id,
                    onChange: (e) => setData("formaPago_id", e.target.value),
                    children: fpago.map((item, idx) => /* @__PURE__ */ jsx(
                      "option",
                      {
                        value: item.id,
                        children: item.nombre
                      },
                      idx
                    ))
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.formaPago_id, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full block", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "monto",
                    value: "Monto"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "monto",
                    value: data.monto,
                    type: "number",
                    step: "0.01",
                    min: "0.1",
                    max: "999999",
                    className: "w-full",
                    onChange: (e) => setData("monto", e.target.value),
                    required: true
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: data.monto === 0 ? errors.monto = "no  hay pago pendiente " : errors.monto, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full block", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "referencia",
                    value: "Referencia"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "referencia",
                    value: data.referencia,
                    required: true,
                    className: "w-full",
                    onChange: (e) => setData("referencia", e.target.value)
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.referencia, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full ", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "observacion",
                    value: "Observación"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    name: "observacion",
                    value: data.observacion,
                    required: true,
                    className: "w-full",
                    onChange: (e) => setData("observacion", e.target.value)
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.observacion, className: "mt-2" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                type: "submit",
                disabled: processing,
                children: "Enviar"
              }
            ) })
          ] })
        ] })
      ]
    }
  );
}
export {
  FormularioPago as default
};
