import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { useForm, Head, router } from "@inertiajs/react";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Create({ auth, flash, dataHuespede }) {
  useState(true);
  const { data, setData, processing, errors, reset, post, put } = useForm({
    ...dataHuespede
  });
  const submit = (e) => {
    console.log("enviando");
    e.preventDefault();
    put(route("huespede.put"), {
      onBefore: () => confirm("Desea enviar"),
      onError: (error) => console.log(error)
    });
  };
  const onBack = (e) => {
    e.preventDefault();
    router.get(route("huespede.get"));
  };
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: "Editar",
      children: /* @__PURE__ */ jsxs(MainHtml, { children: [
        /* @__PURE__ */ jsx(Head, { title: "Editar" }),
        /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "bg-blue-600 ",
            onClick: (e) => onBack(e),
            children: "Regresar"
          }
        ) }),
        /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "block w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "nombre",
                  value: "Nombre"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "nombre",
                  className: "mt-1 block w-full",
                  value: data.nombre,
                  autoComplete: "nombre",
                  isFocused: true,
                  onChange: (e) => setData("nombre", e.target.value),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.nombre, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "apellidos",
                  value: "Apellidos",
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "apellidos",
                  className: "mt-1 block w-full",
                  value: data.apellidos,
                  autoComplete: "apellidos",
                  onChange: (e) => setData("apellidos", e.target.value),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.apellidos, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "nacimiento",
                  value: "Fecha Nacimiento",
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "nacimiento",
                  className: "mt-1 block w-full",
                  value: data.nacimiento,
                  autoComplete: "nacimiento",
                  type: "date",
                  onChange: (e) => setData("nacimiento", e.target.value),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.nacimiento, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2 mt-2 ", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full    ", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "nacionalidad",
                  value: "Nacionalidad"
                }
              ),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  className: "rounded-lg block w-full",
                  value: data.nacionalidad,
                  onChange: (e) => setData("nacionalidad", e.target.value),
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "V", children: "Venezolano" }),
                    /* @__PURE__ */ jsx("option", { value: "E", children: "Extranjero" })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "cedula",
                  value: "Cedula",
                  required: true,
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "cedula",
                  type: "number",
                  className: "mt-1 block w-full",
                  value: data.cedula,
                  disabled: true,
                  onChange: (e) => setData("cedula", e.target.value),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.cedula, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "pasaporte",
                  value: "Pasaporte",
                  required: true,
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "pasaporte",
                  type: "number",
                  className: "mt-1 block w-full",
                  value: data.pasaporte,
                  onChange: (e) => setData("pasaporte", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.pasaporte, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "estadocivil",
                  value: "Estado Civil",
                  required: true,
                  className: "mt-1"
                }
              ),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  className: "w-full rounded-md",
                  value: data.estadocivil,
                  name: "estadocivil",
                  onChange: (e) => setData("estadocivil", e.target.value),
                  children: [
                    /* @__PURE__ */ jsx("option", { value: "S", children: "Soltero" }),
                    /* @__PURE__ */ jsx("option", { value: "C", children: "Casado" }),
                    /* @__PURE__ */ jsx("option", { value: "D", children: "Divorciado" }),
                    /* @__PURE__ */ jsx("option", { value: "V", children: "Viudo" })
                  ]
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.estadocivil, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "profesion",
                value: "Profesion",
                className: ""
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "profesion",
                type: "text",
                className: "mt-1 block w-full",
                value: data.profesion,
                onChange: (e) => setData("profesion", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.profesion, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2 mt-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "procencia",
                  value: "Procedencia",
                  required: true,
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "procedencia",
                  type: "text",
                  className: "mt-1 block w-full",
                  value: data.procedencia,
                  onChange: (e) => setData("procedencia", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.procedencia, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "destino",
                  value: "Destino",
                  required: true,
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "destino",
                  type: "text",
                  className: "mt-1 block w-full",
                  value: data.destino,
                  onChange: (e) => setData("destino", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.pasaporte, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2  mt-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "telefono",
                  value: "Telefono Local",
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "telefono",
                  type: "text",
                  className: "mt-1 block w-full",
                  value: data.telefono,
                  onChange: (e) => setData("telefono", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.telefono, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "celular",
                  value: "Telefono Celular ",
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "celular",
                  type: "text",
                  className: "mt-1 block w-full",
                  value: data.celular,
                  onChange: (e) => setData("celular", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.celular, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "email",
                  value: "Email",
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "email",
                  type: "email",
                  className: "mt-1 block w-full",
                  value: data.email,
                  onChange: (e) => setData("email", e.target.value),
                  required: true
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.email, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "direccion",
                value: "Dirección",
                className: ""
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "direccion",
                type: "text",
                className: "mt-1 block w-full",
                value: data.direccion,
                onChange: (e) => setData("direccion", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.direccion, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2 mt-2", children: [
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "vehiculo",
                  value: "Vehiculo",
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "vehiculo",
                  type: "text",
                  className: "mt-1 block w-full",
                  value: data.vehiculo,
                  onChange: (e) => setData("vehiculo", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.vehiculo, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "placa",
                  value: "Placa",
                  className: ""
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  id: "placa",
                  type: "text",
                  className: "mt-1 block w-full",
                  value: data.placa,
                  onChange: (e) => setData("placa", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.placa, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              disabled: processing,
              children: "Enviar"
            }
          ) })
        ] })
      ] })
    }
  );
}
export {
  Create as default
};
