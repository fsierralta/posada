import { jsx, jsxs } from "react/jsx-runtime";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { M as Mensaje } from "./Mensaje-DW7XXhCF.js";
import { P as Pagination } from "./Pagination-DLE3c5Ab.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { S as SecondaryButton } from "./SecondaryButton-BQS06wJz.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { useForm, Head, router } from "@inertiajs/react";
import { useState, useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Index({ auth, data, flash }) {
  const [mostrar, setMostrar] = useState(false);
  const { data: dataPrecio, links } = data;
  const { delete: destroy } = useForm();
  const createItem = (e) => {
    e.preventDefault();
    router.get(route("precio.create"));
  };
  const editarItem = (e) => {
    e.preventDefault();
    let id = e.target.value;
    router.get(route("precio.show", { id }));
  };
  const eliminarItem = (e) => {
    e.preventDefault();
    let id = e.target.value;
    destroy(route("precio.destroy", { id }), {
      onBefore: () => window.confirm(`Desea eliminar este item:${id}`)
    });
  };
  useEffect(() => {
    const MostrarMensaje = () => {
      setMostrar(true);
      setTimeout(() => {
        setMostrar(false);
        flash.message = null;
      }, 3e3);
    };
    flash.message && MostrarMensaje();
  }, [flash]);
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: "Precio base",
      children: /* @__PURE__ */ jsxs(MainHtml, { children: [
        /* @__PURE__ */ jsx(Head, { title: "Precio Base" }),
        /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            onClick: createItem,
            children: "Create"
          }
        ) }),
        mostrar && /* @__PURE__ */ jsx(Mensaje, { mensaje: flash.message }),
        /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
          dataPrecio.length > 0 ? /* @__PURE__ */ jsxs("table", { className: "table-auto  border border-green-700\r\n                                     border-separate border-spacing-2 w-full", children: [
            /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-green-300", children: [
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "id" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "precio" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Descipción" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Tipo" }),
              /* @__PURE__ */ jsx("th", { children: "Editar" }),
              /* @__PURE__ */ jsx("th", { children: "Eliminar" })
            ] }) }),
            /* @__PURE__ */ jsx("tbody", { children: dataPrecio.length > 0 && dataPrecio.map((item, idx) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsxs("td", { className: "border border-green-700", children: [
                " ",
                item.id
              ] }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.precio }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.descripcion }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.tipo }),
              /* @__PURE__ */ jsxs("td", { children: [
                /* @__PURE__ */ jsx(
                  PrimaryButton,
                  {
                    name: "btnEditar",
                    value: item.id,
                    onClick: editarItem,
                    children: "Editar"
                  }
                ),
                " "
              ] }),
              /* @__PURE__ */ jsx("td", { children: /* @__PURE__ */ jsx(
                SecondaryButton,
                {
                  name: "btnEliminar",
                  value: item.id,
                  onClick: eliminarItem,
                  children: "Eliminar"
                }
              ) })
            ] }, item.id)) })
          ] }) : /* @__PURE__ */ jsx("span", { children: "No  hay datos" }),
          /* @__PURE__ */ jsxs("div", { className: "mt-2", children: [
            /* @__PURE__ */ jsx(
              Pagination,
              {
                links
              }
            ),
            " "
          ] })
        ] })
      ] })
    }
  );
}
export {
  Index as default
};
