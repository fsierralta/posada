import { jsxs, jsx } from "react/jsx-runtime";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { Head, router } from "@inertiajs/react";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { useState, useEffect } from "react";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { M as Modal } from "./Modal-Vm18LNJq.js";
import { S as SecondaryButton } from "./SecondaryButton-BQS06wJz.js";
import { M as Mensaje } from "./Mensaje-DW7XXhCF.js";
import { f as fechaFormato_dmy } from "./help-CPaU3KEz.js";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Dashboard({ auth, flash, dataPosada, huespedesRegistrados }) {
  const [selectPosada, setSelectPosada] = useState(0);
  const [show, setshow] = useState(false);
  const [enviar, setEnviar] = useState(false);
  const [mostrar, setMostrarMessage] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const onClose = (e) => {
    let onSumit = e.target.value;
    setEnviar(onSumit);
    setshow(false);
  };
  const estatusPosada = (posada_id) => {
    const posada = dataPosada.find((item, id) => {
      if (item.id === posada_id) {
        return item;
      }
    });
    return posada.estatus;
  };
  const seleccionada = (id) => {
    return id === selectPosada ? "border-collapse border-green-400 shadow-black bg-blue-100 cursor-pointer" : "border-collapse border-blue-400 shadow-black bg-green-100  cursor-pointer";
  };
  const onSelectPosada = (id) => {
    setSelectPosada(id);
    onHoverMouseCabana(id);
  };
  const onHoverMouseCabana = (id) => {
    if (estatusPosada(id) === "O") {
      const huespede = huespedesRegistrados.find((item) => item.posada_id == id);
      if (huespede) {
        flash.message = `Huespede :${huespede.nombre} Entrada:${fechaFormato_dmy(huespede.fechaEntrada)} Salida:${fechaFormato_dmy(huespede.fechaSalida)}`;
        setMostrarMessage(true);
      }
    }
  };
  const urlImg = (estatus) => {
    return estatus === "D" ? "/imagenes/circulo_verde.jpg" : "/imagenes/circulo_rojo.jpg";
  };
  const alquilarPosada = (e) => {
    e.preventDefault();
    if (selectPosada && estatusPosada(selectPosada) === "D") {
      router.get(route("registrohuespede.get", selectPosada));
    } else {
      flash.message = "Cabaña ocupada.. no se puede alquilar";
      setMostrarMessage(true);
    }
  };
  const registrarPago = (e) => {
    e.preventDefault();
    if (selectPosada && estatusPosada(selectPosada) === "O") {
      selectPosada && router.get(route("registrohuespedepago.show", selectPosada));
    } else {
      flash.message = "Cabaña Desocupada.. no se puede registrar pago";
      setMostrarMessage(true);
    }
  };
  const estadoCta = (e) => {
    e.preventDefault();
    if (selectPosada && estatusPosada(selectPosada) === "O") {
      selectPosada && router.get(route("estadocta.show", selectPosada));
    } else {
      flash.message = "Cabaña Desocupada.. no se puede emitir estado cta";
      setMostrarMessage(true);
    }
  };
  const registrarConsumo = (e) => {
    e.preventDefault();
    if (selectPosada && estatusPosada(selectPosada) === "O") {
      selectPosada && router.get(route("cargoconsumo.get", selectPosada));
    } else {
      flash.message = "Cabaña Desocupada.. no se puede registrar consumo";
      setMostrarMessage(true);
    }
  };
  const darDeAlta = (e) => {
    e.preventDefault();
    if (selectPosada && estatusPosada(selectPosada) === "O") {
      selectPosada && router.get(route("notafactura.get", selectPosada));
    } else {
      flash.message = "Cabaña Desocupada.. no se puede dar de alta";
      setMostrarMessage(true);
    }
  };
  const CajaShow = () => {
    router.get(route("caja.show"));
  };
  useEffect(() => {
    if (flash == null ? void 0 : flash.message) {
      setMostrarMessage(true);
    }
  }, [flash]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Dashboard" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Dashboard" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsx("div", { className: "w-full h-6 my-6", children: mostrar ? /* @__PURE__ */ jsx(
            Mensaje,
            {
              mensaje: flash.message,
              setMostrar: setMostrarMessage,
              setMensaje
            }
          ) : /* @__PURE__ */ jsx("h1", { className: "bg-green-500 rounded-lg  text-2xl block w-full my-4", children: "Seleccione una Operación" }) }),
          show && /* @__PURE__ */ jsx(
            Modal,
            {
              show,
              onClose,
              children: /* @__PURE__ */ jsxs("div", { className: "space-x-2", children: [
                /* @__PURE__ */ jsx("div", { className: "w-full", children: /* @__PURE__ */ jsx("span", { className: "font-bold text-xl text-center block w-full bg-green-300", children: "Desea " }) }),
                /* @__PURE__ */ jsxs("div", { className: "flex justify-center space-x-2 py-6", children: [
                  /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
                    PrimaryButton,
                    {
                      name: "enviar",
                      value: true,
                      onClick: onClose,
                      children: "Enviar"
                    }
                  ) }),
                  /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
                    SecondaryButton,
                    {
                      name: "cancelar",
                      value: false,
                      onClick: onClose,
                      children: "Cancelar"
                    }
                  ) })
                ] })
              ] })
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: " justify-center mx-auto\n                                         flex flex-wrap \n                                         gap-2 py-2 \n                                         sm:mb-14 \n                                         rounded-lg my-3 space-x-2\n                                         md:bg-slate-300\n                                         sm:bg-white", children: [
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-400 ",
                id: "btnAlquilar",
                name: "btnAlquilar",
                onClick: alquilarPosada,
                children: "Alquilar"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-500 ",
                id: "btnPago",
                name: "btnPago",
                onClick: registrarPago,
                children: "Registrar Pago"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-600 ",
                onClick: registrarConsumo,
                name: "btnConsumo",
                children: "Cargar un consumo"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-700",
                name: "btnEstadoCta",
                id: "btnEstadoCta",
                onClick: estadoCta,
                children: "Estado Cta"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-800",
                children: "Cambiar de Cabaña"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-800",
                children: "F. Salida"
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-900",
                name: "btnDarDeAlta",
                onClick: darDeAlta,
                children: " Dar de Alta "
              }
            ),
            /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                className: "bg-green-400",
                name: "btnCaja",
                onClick: CajaShow,
                children: " Caja "
              }
            )
          ] }),
          dataPosada.length > 0 ? /* @__PURE__ */ jsx("div", { className: "grid md:grid-cols-3 gap-4 sm:grid sm:grid-cols-1   ", children: dataPosada.map((item, idx) => /* @__PURE__ */ jsx(
            "div",
            {
              className: seleccionada(item.id),
              onClick: () => onSelectPosada(item.id),
              children: /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: urlImg(item.estatus),
                    alt: "posada",
                    width: "20",
                    height: "20"
                  }
                ) }),
                /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
                  "img",
                  {
                    src: "/imagenes/logo.png",
                    alt: "posada",
                    className: "bg-green-50 object-fill rounded-lg",
                    width: "100",
                    height: "100"
                  }
                ) }),
                /* @__PURE__ */ jsx("div", { className: "font-bold text-center text-amber-800 text-lg ", children: `${item.nombre}` }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("div", { className: "text-center font-bold", children: /* @__PURE__ */ jsx("span", { children: `Capacidad:${item.capacidad}` }) }),
                  /* @__PURE__ */ jsx("div", { className: "text-center font-bold ", children: /* @__PURE__ */ jsx("span", { children: item.descripcion }) })
                ] })
              ] })
            },
            item.id
          )) }) : /* @__PURE__ */ jsx("p", { children: "sin data" })
        ] })
      ]
    }
  );
}
export {
  Dashboard as default
};
