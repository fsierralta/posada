import { jsx, jsxs } from "react/jsx-runtime";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { M as Mensaje } from "./Mensaje-DW7XXhCF.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { useForm, Head, Link } from "@inertiajs/react";
import axios from "axios";
import { useState, useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Consumo({ auth, flash, dataPago }) {
  const { posada, huespede, fichaRegistroH, precios } = dataPago;
  const [mostrar, setMostrar] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [urlTicket, setUrlTicket] = useState({
    id: 0,
    url: "repo.01",
    activate: true
  });
  const { data, setData, processing, pos, errors, post, reset } = useForm({
    precio_id: 0,
    descripcion: "",
    nrodias: 1,
    // para efecto del consumo es uno se trabaja cantidad y precio / total
    cantidad: 0,
    montoTotal: 0,
    nroficha: fichaRegistroH.nroficha,
    posada_id: posada.id,
    huespede_id: huespede.id,
    precio: 0
  });
  const onSubmitHuespede = async (e) => {
    e.preventDefault();
    if (data.precio_id === 0 || data.montoTotal === 0 || data.descripcion.length === 0) {
      setMensaje("Debe indicar el precio/Descripcion/montoTotal");
      setMostrar(true);
      return;
    }
    let ok = window.confirm("Desea Enviar?");
    if (!ok) {
      return;
    }
    console.log(data);
    let response = await axios.post(route("cargoconsumo.store", data));
    try {
      if (response.status === 200) {
        console.log(response);
        let urlprevio = urlTicket;
        urlprevio.id = response.data.id;
        urlprevio.activate = true;
        setUrlTicket(urlprevio);
        console.log(urlprevio);
        setMensaje("Ticket listo para imprimir ");
        setMostrar(true);
        reset("cantidad", "montoTotal", "precio", "precio_id");
      }
    } catch (error) {
      console.log(error);
    }
  };
  const calcularTotal = () => {
    console.log(data);
    const objprecioEncontrado = precios.find((item) => {
      if (item.id === parseInt(data.precio_id)) {
        return item;
      } else {
        console.log(item);
      }
    });
    if ((objprecioEncontrado == null ? void 0 : objprecioEncontrado.precio) > 0) {
      let total = data.nrodias * data.cantidad * data.precio;
      setData("montoTotal", total);
    } else {
      setMensaje("Precio no encotrando");
      setMostrar(true);
    }
  };
  useEffect(() => {
    data.cantidad > 0 && calcularTotal();
  }, [data.cantidad, data.precio]);
  useEffect(() => {
    const objePrecio = (precio_id) => {
      let itemprecio = precios.find((item) => item.id === precio_id);
      console.log(itemprecio);
      const previodata = data;
      previodata.descripcion = itemprecio == null ? void 0 : itemprecio.descripcion;
      previodata.precio = itemprecio == null ? void 0 : itemprecio.precio;
      setData(previodata);
      (itemprecio == null ? void 0 : itemprecio.id) > 0 ? setData("precio", parseInt(itemprecio.precio)) : setData("precio", 0);
    };
    data.precio_id >= 0 && objePrecio(data.precio_id);
  }, [data.precio_id]);
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: "Consumos Cliente",
      children: /* @__PURE__ */ jsxs(MainHtml, { children: [
        /* @__PURE__ */ jsx(Head, { title: "ConsumoCliente" }),
        /* @__PURE__ */ jsx("div", { children: mostrar && /* @__PURE__ */ jsx(
          Mensaje,
          {
            mensaje,
            setMostrar,
            setMensaje
          }
        ) }),
        /* @__PURE__ */ jsxs("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              href: route("dashboard"),
              className: "bg-gray-900 text-white rounded-md space-y-2 hover:bg-slate-600\r\n                             px-2 py-2\r\n                 ",
              children: "Regresar"
            }
          ),
          urlTicket.id > 0 && /* @__PURE__ */ jsx(
            "a",
            {
              href: urlTicket.id === 0 ? "#" : route(urlTicket.url, urlTicket.id),
              disabled: urlTicket.activate,
              target: "_blank",
              className: "bg-blue-900 ml-2 text-white rounded-md space-y-2 hover:bg-slate-600\r\n                                    px-2 py-2\r\n                        ",
              children: "ticket"
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("form", { onSubmit: onSubmitHuespede, children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "posadanombre",
                value: "Nombre Posada"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                type: "text",
                defaultValue: posada.nombre,
                name: "posadanombre",
                disabled: true
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { className: " flex grid-cols-3 space-x-2 mt-2", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "cedula",
                  value: "Cedula"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "text",
                  defaultValue: `${huespede.nacionalidad}${huespede.cedula}`,
                  name: "cedula",
                  className: "font-bold",
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "block w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "nroficha",
                  value: "Nro Ficha"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "text",
                  defaultValue: `${fichaRegistroH.nroficha}`,
                  name: "nroficha",
                  className: "w-full font-bold",
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "block w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "nombreHuespedes",
                  value: "Nombre Huespede"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "text",
                  defaultValue: `${huespede.nombre}${huespede.apellidos}`,
                  name: "nombrehuespedes",
                  className: "w-full font-bold",
                  disabled: true
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-2 flex   space-x-2  ", children: [
            /* @__PURE__ */ jsxs("div", { className: "", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "fechaEntrada",
                  value: "Fecha Entrada"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "date",
                  required: true,
                  name: "fechaEntrada",
                  defaultValue: fichaRegistroH.fechaEntrada,
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "fechaSalida",
                  value: "Fecha Salida"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "date",
                  required: true,
                  name: "fechaSalida",
                  defaultValue: `${fichaRegistroH.fechaSalida}`,
                  disabled: true
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-2 flex  space-x-2", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                value: "Asignar Consumo "
              }
            ),
            /* @__PURE__ */ jsxs(
              "select",
              {
                className: "w-full mt-2 rounded-lg ",
                name: "precio_id",
                value: data.precio_id,
                onChange: (e) => setData("precio_id", parseInt(e.target.value)),
                children: [
                  /* @__PURE__ */ jsx(
                    "option",
                    {
                      value: 0,
                      children: `|id|Descripcion|Precio $|`
                    },
                    0
                  ),
                  precios.map((item, idx) => /* @__PURE__ */ jsx(
                    "option",
                    {
                      value: item.id,
                      children: `|${item.id}|${item.descripcion}|${item.precio}$|`
                    },
                    item.id
                  ))
                ]
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.precio_id, className: "mt-2" })
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "w-full ", children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "descripcion",
                value: "Descripcion"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                className: "mt-2 w-full",
                type: "text",
                required: true,
                name: "descripcion",
                value: data.descripcion,
                onChange: (e) => setData("descripcion", e.target.value)
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.descripcion, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex mt-2 space-x-2", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "precio",
                  value: "precio"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  className: "mt-2",
                  type: "number",
                  required: true,
                  step: "0.01",
                  min: "0.1",
                  name: "precio",
                  value: data.precio,
                  onChange: (e) => setData("precio", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.precio, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "cantidad",
                  value: "Cantidad"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  className: "mt-2",
                  type: "number",
                  step: "1",
                  required: true,
                  min: "1",
                  name: "cantidad",
                  value: data.cantidad,
                  onChange: (e) => setData("cantidad", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.cantidad, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "montoTotal",
                  value: "Total"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  className: "mt-2",
                  type: "text",
                  step: "1",
                  required: true,
                  name: "montoTotal",
                  disabled: true,
                  value: data.montoTotal
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.montoTotal, className: "mt-2" })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              type: "submit",
              name: "btnSumit",
              disabled: processing,
              children: "Enviar"
            }
          ) })
        ] })
      ] })
    }
  );
}
export {
  Consumo as default
};
