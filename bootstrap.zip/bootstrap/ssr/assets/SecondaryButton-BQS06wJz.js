import { jsx } from "react/jsx-runtime";
function SecondaryButton({ type = "button", className = "", disabled, children, ...props }) {
  return /* @__PURE__ */ jsx(
    "button",
    {
      ...props,
      type,
      className: `inline-flex items-center px-4 py-2 border-gray-300 
                rounded-md font-semibold text-xs
                 text-gray-700 uppercase tracking-widest shadow-sm
                  hover:bg-gray-50 focus:outline-none focus:ring-2
                 focus:ring-indigo-500 
                 focus:ring-offset-2 disabled:opacity-25 transition
                 ease-in-out duration-150 ${disabled && "opacity-25"} ` + className,
      disabled,
      children
    }
  );
}
export {
  SecondaryButton as S
};
