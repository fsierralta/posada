import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { M as Mensaje } from "./Mensaje-DW7XXhCF.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { S as SecondaryButton } from "./SecondaryButton-BQS06wJz.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { G as Guest } from "./GuestLayout-Dq2bCslE.js";
import { useForm, Head } from "@inertiajs/react";
import axios from "axios";
import { useState, useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
function Contacto({ flash }) {
  const [mostrar, setMostrarMessage] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [errorsAxios, setErrorsAxios] = useState([{}]);
  const { data, setData, processing, post, errors } = useForm({
    "nombre": "",
    "apellidos": "",
    "nacionalidad": "V",
    "cedula": "",
    "nacimiento": "",
    "celular": "",
    "email": "",
    "direccion": "",
    "verificationcode": ""
  });
  const onSubmitFrm = (e) => {
    e.preventDefault();
    console.log("onsubmit");
    post(route("contacto.store", data));
  };
  const getCodigo = (e) => {
    e.preventDefault();
    setErrorsAxios([{}]);
    axios.get(route("contactocode.get", data)).then((response) => {
      console.log(response);
      setMensaje(response.data.message);
      setMostrarMessage(true);
    }).catch((error) => {
      const { errors: arrayError } = error.response.data;
      console.log(arrayError);
      if (Object.keys(arrayError)) {
        setErrorsAxios(Object.values(arrayError));
        for (const [key, value] of Object.entries(arrayError)) {
          console.log(`key:${key} value:${value[0]}`);
          errors[key] = value[0];
        }
      }
    });
  };
  useEffect(() => {
    const mostrar2 = () => {
      setMensaje(flash.message);
      setMostrarMessage(true);
      flash.message = null;
    };
    (flash == null ? void 0 : flash.message) && mostrar2();
  }, [flash == null ? void 0 : flash.message]);
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Registro de contacto" }),
    /* @__PURE__ */ jsx("h1", { className: "text-green-500 font-bold text-2xl text-center", children: "Contacto" }),
    /* @__PURE__ */ jsx("div", { className: "w-full h-6 my-6", children: mostrar ? /* @__PURE__ */ jsx(
      Mensaje,
      {
        mensaje,
        setMostrar: setMostrarMessage,
        setMensaje
      }
    ) : /* @__PURE__ */ jsx("h1", { className: "bg-green-500 rounded-lg  text-2xl block w-full my-4", children: "Solicite codigo de registro" }) }),
    /* @__PURE__ */ jsx("form", { onSubmit: onSubmitFrm, children: /* @__PURE__ */ jsxs("div", { className: "mt-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: "nombre",
              value: "Nombres"
            }
          ),
          /* @__PURE__ */ jsx(
            TextInput,
            {
              name: "nombre",
              className: "w-full",
              value: data.nombre,
              required: true,
              onChange: (e) => setData("nombre", e.target.value)
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.nombre })
        ] }),
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: "apellidos",
              value: "Apellidos"
            }
          ),
          /* @__PURE__ */ jsx(
            TextInput,
            {
              name: "apellidos",
              className: "w-full",
              value: data.apellidos,
              onChange: (e) => setData("apellidos", e.target.value),
              required: true
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.apellidos })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2 mt-2  ", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: "nacionalidad",
              value: "Nacionalidad"
            }
          ),
          /* @__PURE__ */ jsxs(
            "select",
            {
              name: "nacionalidad",
              className: "w-full rounded-md",
              value: data.nacionalidad,
              onChange: (e) => setData("nacionalidad", e.target.value),
              children: [
                /* @__PURE__ */ jsx("option", { value: "V", children: "Venezolano" }),
                /* @__PURE__ */ jsx("option", { value: "E", children: "Extranjero" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
          /* @__PURE__ */ jsx(
            InputLabel,
            {
              htmlFor: "cedula",
              value: "Nro Identificación"
            }
          ),
          /* @__PURE__ */ jsx(
            TextInput,
            {
              name: "cedula",
              className: "w-full ",
              value: data.cedula,
              onChange: (e) => setData("cedula", e.target.value),
              required: true
            }
          ),
          /* @__PURE__ */ jsx(InputError, { message: errors.cedula })
        ] })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full mt-2", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "nacimiento",
            value: "Fecha Nacimiento"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            name: "nacimiento",
            type: "date",
            className: "w-full",
            value: data.nacimiento,
            onChange: (e) => setData("nacimiento", e.target.value),
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.nacimiento })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-2 w-full", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "celular",
            value: "Celular Nro"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            name: "celular",
            className: "w-full",
            value: data.celular,
            onChange: (e) => setData("celular", e.target.value),
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.celular })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full mt-2", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "email",
            value: "Email"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            className: "w-full",
            name: "email",
            type: "email",
            value: data.email,
            onChange: (e) => setData("email", e.target.value),
            required: true
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.email })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "direccion",
            value: "Direccion"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            name: "direccion",
            value: data.direccion,
            onChange: (e) => setData("direccion", e.target.value),
            className: "w-full"
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.direccion })
      ] }),
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "codigo",
            value: "Codigo"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            name: "verificationcode",
            value: data.verificationcode,
            onChange: (e) => setData("verificationcode", e.target.value),
            required: true,
            placeholder: "Ingrese el codigo enviado a su correo",
            className: "w-full"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex  gap-2 justify-center mt-4 border border-collapse border-black rounded-lg py-2 ", children: [
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            name: "btnEnviar",
            type: "submit",
            disabled: processing,
            children: "Enviar"
          }
        ),
        /* @__PURE__ */ jsx(
          SecondaryButton,
          {
            name: "btnCodigo",
            onClick: getCodigo,
            className: "bg-green-300 hover:bg-orange-400",
            children: "Solicitar Codigo"
          }
        ),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "https://www.instagram.com/myopticc/",
            target: "_blank",
            className: "bg-red-400 rounded-md px-2 py-2 hover:bg-orange-400",
            children: "MY OPTIC"
          }
        )
      ] })
    ] }) })
  ] });
}
export {
  Contacto as default
};
