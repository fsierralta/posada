import { jsx } from "react/jsx-runtime";
import "react";
import { Link } from "@inertiajs/react";
const PageLink = ({ active, label, url }) => {
  const className = " mr-1 mb-1 px-4 py-3 text-sm border rounded border-solid border-gray-300 text-gray";
  return /* @__PURE__ */ jsx(
    Link,
    {
      className: active ? "bg-green-500 " + className : className,
      href: url,
      children: /* @__PURE__ */ jsx("span", { dangerouslySetInnerHTML: { __html: label } })
    }
  );
};
const PageInactive = ({ label }) => {
  const className = "mr-1 mb-1 px-4 py-3 text-sm border rounded border-solid border-gray-300 text-gray";
  return /* @__PURE__ */ jsx("div", { className, dangerouslySetInnerHTML: { __html: label } });
};
const Pagination = ({ links = [] }) => {
  if (links.length === 3) return null;
  return /* @__PURE__ */ jsx("div", { className: "flex flex-wrap mt-1 -mb-1", children: links.map(({ active, label, url }) => {
    return url === null ? /* @__PURE__ */ jsx(PageInactive, { label }, label) : /* @__PURE__ */ jsx(PageLink, { label, active, url }, label);
  }) });
};
export {
  Pagination as P
};
