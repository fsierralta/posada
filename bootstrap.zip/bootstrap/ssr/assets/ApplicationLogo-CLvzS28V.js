import { jsx } from "react/jsx-runtime";
function ApplicationLogo(props) {
  return /* @__PURE__ */ jsx(
    "img",
    {
      src: "/imagenes/logo.png",
      alt: "cargando",
      height: "50",
      width: "50",
      className: "rounded  rounded:lg "
    }
  );
}
export {
  ApplicationLogo as A
};
