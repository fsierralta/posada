import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState, useRef, useEffect } from "react";
import { Link } from "@inertiajs/react";
const Footer = () => {
  return /* @__PURE__ */ jsx("footer", { className: "bg-gray-800 text-gray-300 py-4 px-4 ", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between items-center ", children: [
    /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsxs("p", { children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      "  Todos los derechos reservados.",
      `${"Freddy Sierralta"} ${"+58-412-3138606"}`
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "flex space-x-4", children: /* @__PURE__ */ jsx("p", { className: "hover:text-white", children: `email:${"sierralta.freddy@gmail.com"}` }) }),
    /* @__PURE__ */ jsx("div", { className: "flex space-x-4", children: /* @__PURE__ */ jsx("a", { href: `${"https://www.instagram.com/sierraltafreddy/"}`, target: "_blank", rel: "noopener noreferrer", className: "text-gray-300 hover:text-white", children: /* @__PURE__ */ jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-6 w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: [
      /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M16.463 12.553a2.5 2.5 0 01-2.5 2.5 2.5 2.5 0 01-2.5-2.5 2.5 2.5 0 012.5-2.5 2.5 2.5 0 012.5 2.5zm-5.228 0a7.5 7.5 0 1115 0 7.5 7.5 0 01-15 0z" }),
      /* @__PURE__ */ jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 10v6m0 0l-3-3m3 3l3-3" })
    ] }) }) })
  ] }) });
};
function Slider() {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { children: [
    " ",
    /* @__PURE__ */ jsxs("div", { children: [
      " ",
      /* @__PURE__ */ jsxs("h1", { className: "text-white  text-2xl text-center ", children: [
        `Obten el ${"25"} porciento de Descuento en todas Las Monturas para Lentes  `,
        "En las  Tiendas ",
        /* @__PURE__ */ jsx("span", { className: "text-white text-2xl font-bold", children: "MY OPTIC" })
      ] }),
      /* @__PURE__ */ jsx("h2", { className: "text-xl font-bold mb-2 text-center mt-4", children: "Regístrate Aquí y" }),
      /* @__PURE__ */ jsx("p", { className: "mb-4 text-white", children: "¡Únete a nuestra comunidad y descubre contenido exclusivo!" }),
      /* @__PURE__ */ jsx(
        Link,
        {
          className: "bg-green-500 hover:bg-green-300 text-white font-bold py-2 px-4 rounded w-full mx-auto  block text-center",
          href: route("contacto.show"),
          children: "Registrarse"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-4 text-xl", children: [
      " ",
      /* @__PURE__ */ jsx(
        "a",
        {
          href: ` ${"https://www.instagram.com/myopticc/"}`,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "text-white hover:underline block text-center",
          children: "Síguenos en Instagram MyOPTIC"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-4 text-xl", children: [
      " ",
      /* @__PURE__ */ jsx(
        "a",
        {
          href: `${"https://www.instagram.com/loshumacosposada/"}`,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "text-amber-500 hover:underline block text-center",
          children: "Síguenos en Instagram Posada los Humacos"
        }
      )
    ] })
  ] }) });
}
const Body = () => {
  const [currentImage, setCurrentImage] = useState(0);
  const carouselRef = useRef(null);
  const images = [
    "/imagenes/posada/posada_01.jpg",
    // Reemplaza con tus rutas de imágenes
    "/imagenes/posada/posada_02.jpg",
    "/imagenes/posada/posada_03.jpg",
    "/imagenes/posada/posada_04.jpg",
    "/imagenes/posada/posada_05.jpg",
    "/imagenes/posada/posada_06.jpg",
    "/imagenes/posada/posada_07.jpg",
    "/imagenes/posada/posada_08.jpg",
    "/imagenes/posada/posada_09.jpg"
    // ... más imágenes
  ];
  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentImage((prevImage2) => (prevImage2 + 1) % images.length);
    }, 5e3);
    return () => clearInterval(intervalId);
  }, [images.length]);
  const nextImage = () => {
    setCurrentImage((currentImage + 1) % images.length);
  };
  const prevImage = () => {
    setCurrentImage((currentImage - 1 + images.length) % images.length);
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "w-full justify-items-center flex  ", children: [
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
        "a",
        {
          href: "https://www.instagram.com/loshumacosposada/",
          target: "_blank",
          rel: "noopener noreferrer",
          className: "hover:underline block text-center",
          children: /* @__PURE__ */ jsx("img", { src: "imagenes/posada/logo_02.jpg", alt: "humacos" })
        }
      ) }),
      /* @__PURE__ */ jsx("div", { className: "w-full  justify-items-center", children: /* @__PURE__ */ jsx(
        "a",
        {
          href: "https://www.instagram.com/loshumacosposada/",
          target: "_blank",
          rel: "noopener noreferrer",
          className: "hover:underline block text-center",
          children: /* @__PURE__ */ jsx("img", { src: "imagenes/posada/servicios.jpg", alt: "servicios" })
        }
      ) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col ", children: [
      /* @__PURE__ */ jsxs("div", { className: " md:flex md:flex-row sm:flex   sm:flex-col \r\n                        bg-gradient-to-r\r\n                        from-gray-100\r\n                          via-green-600 to-slate-600  ", children: [
        " ",
        /* @__PURE__ */ jsxs(
          "div",
          {
            className: `md:w-3/4 p-4 sm:w-full h-screen
                              md:justify-items-center relative `,
            children: [
              " ",
              /* @__PURE__ */ jsxs("div", { className: "text-center  mb-6 pt-4   ", children: [
                " ",
                /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxs("h2", { className: "text-2xl md:text-3xl font-bold text-white leading-tight mr-2", children: [
                    " ",
                    /* @__PURE__ */ jsx("p", { children: " Disponemos de cabañas" }),
                    "tradicionales"
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "md:text-2xl sm:text-sm", children: [
                    /* @__PURE__ */ jsx("h1", { children: `Reservaciones:${"loshumacos1@hotmail.com"}` }),
                    /* @__PURE__ */ jsx("h1", { children: `Telefonos ${"+58-0424-3380298"}` })
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "relative w-96 h-96 overflow-hidden  ", children: [
                /* @__PURE__ */ jsx("div", { className: "flex transition-transform duration-500 ease-in-out", style: { transform: `translateX(-${currentImage * 100}%)` }, ref: carouselRef, children: images.map((image, index) => /* @__PURE__ */ jsx("div", { className: "w-full shrink-0  ", children: /* @__PURE__ */ jsx("img", { src: image, alt: `Imagen ${index + 1}`, className: "object-fill w-full " }) }, index)) }),
                /* @__PURE__ */ jsx("button", { onClick: prevImage, className: "absolute left-0 top-1/2 transform -translate-y-1/2 bg-gray-800 text-white p-2 rounded-full opacity-70 hover:opacity-100", children: "<" }),
                /* @__PURE__ */ jsx("button", { onClick: nextImage, className: "absolute right-0 top-1/2 transform -translate-y-1/2 bg-gray-800 text-white p-2 rounded-full opacity-70 hover:opacity-100", children: ">" })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mt-8", children: /* @__PURE__ */ jsxs("p", { className: "text-2xl md:text-3xl font-bold text-white leading-tight mx-auto ml-2 text-center", children: [
                " ",
                "Rodeadas de un hermoso ",
                /* @__PURE__ */ jsx("span", { children: "paisaje" })
              ] }) })
            ]
          }
        ),
        /* @__PURE__ */ jsx(
          "div",
          {
            className: "md:w-1/4 md:flex\r\n                        md:border \r\n                        md:border-collapse \r\n                        md:rounded-lg md:border-black px-4 \r\n                          bg-gradient-to-r\r\n                        from-gray-100\r\n                        via-green-600 to-slate-600 \r\n                          py-12",
            children: /* @__PURE__ */ jsx(Slider, {})
          }
        )
      ] }),
      /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Footer, {}) })
    ] })
  ] });
};
const Navbar = ({ auth }) => {
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("nav", { className: "bg-gradient-to-r from-slate-800 to-slate-900 h-10   items-center justify-between px-4 flex", children: [
    /* @__PURE__ */ jsxs("div", { className: "text-white font-bold", children: [
      " ",
      `${"POSADA LOS HUMACOS"}`
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex space-x-4", children: " " }),
    /* @__PURE__ */ jsxs("div", { className: "flex space-x-2", children: [
      " ",
      auth.user ? /* @__PURE__ */ jsx(
        Link,
        {
          href: route("dashboard"),
          className: "text-gray-300 hover:text-white",
          children: "Dashboard"
        }
      ) : /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(
        Link,
        {
          href: route("login"),
          className: "text-gray-300 hover:text-white",
          children: "Log in"
        }
      ) })
    ] })
  ] }) });
};
const App = ({ auth, children }) => {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsx(
      Navbar,
      {
        auth
      }
    ),
    /* @__PURE__ */ jsxs("main", { children: [
      children,
      " "
    ] })
  ] });
};
function WelcomeNew({ auth, laravelVersion = "", phpVersion = "" }) {
  return /* @__PURE__ */ jsx(
    App,
    {
      auth,
      children: /* @__PURE__ */ jsx(Body, {})
    }
  );
}
export {
  WelcomeNew as default
};
