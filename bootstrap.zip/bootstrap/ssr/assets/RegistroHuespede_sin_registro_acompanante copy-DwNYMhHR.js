import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { M as Mensaje } from "./Mensaje-DW7XXhCF.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { useForm, Head, Link } from "@inertiajs/react";
import axios from "axios";
import { useState, useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function RegistroHuespede({ auth, flash, dataRegistro }) {
  const [nombreApellido, setNombreApellidos] = useState("");
  const [mostrar, setMostrar] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const { data, setData, post, processing, errors } = useForm({
    ...dataRegistro,
    precio_id: 0,
    nrodias: 0,
    nropersonas: 0,
    montoTotal: 0,
    descripcion: "Hospedaje para"
  });
  const getDataHuespede = async (e) => {
    e.preventDefault();
    try {
      let response = await axios.get(route("registrohuespedecedula.get", data.cedula.toUpperCase()));
      if (response.status === 200) {
        console.log(response);
        const { nombre, apellidos } = response.data.dataHuespede;
        setMensaje("Registro Encontrado");
        setMostrar(true);
        setNombreApellidos(nombre.concat(" ", apellidos));
      }
      console.log(response);
    } catch (error) {
      console.log(error.response.data.dataHuespede);
      setMensaje(error.response.data.dataHuespede);
      setMostrar(true);
    }
  };
  const onSubmitHuespede = (e) => {
    e.preventDefault();
    if (data.nrodias !== nroDiasEstadia()) {
      setMensaje("Los dias de estadias , no concuerdan con la fecha de salida");
      setMostrar(true);
      return;
    }
    if (data.montoTotal === 0) {
      setMensaje("Debe calcular el monto de la la estadia del huespede");
      setMostrar(true);
      return;
    }
    try {
      post(route("registrohuespede.store", data), {
        onBefore: () => window.confirm("Desea Enviar"),
        onError: (error) => console.log(error)
      });
    } catch (error) {
    }
  };
  const calcularTotal = (e) => {
    e.preventDefault();
    const precios = data.precios;
    const objprecioEncontrado = precios.find((item) => {
      if (item.id === parseInt(data.precio_id)) {
        console.log(`encontrado:${item.precio}`);
        return item;
      }
    });
    if ((objprecioEncontrado == null ? void 0 : objprecioEncontrado.precio) > 0) {
      let total = data.nrodias * data.nropersonas * objprecioEncontrado.precio;
      setData("montoTotal", total);
    } else {
      setMensaje("Precio no encotrando");
      setMostrar(true);
    }
  };
  const nroDiasEstadia = () => {
    const diasMilisegundos = new Date(data.fechaSalida) - new Date(data.fechaEntrada);
    const nroDias = Math.round(diasMilisegundos / (1e3 * 60 * 60 * 24));
    if (nroDias === 0) {
      setData("nrodias", nroDias + 1);
    } else nroDias < 0 ? setData("nrodias", 0) : setData("nrodias", nroDias);
    return nroDias;
  };
  useEffect(() => {
    data.fechaSalida != null && nroDiasEstadia();
  }, [data.fechaSalida]);
  useEffect(() => {
    const mostrar2 = () => {
      if ((flash == null ? void 0 : flash.message) !== null) {
        setMensaje(flash.message);
        setMostrar(true);
      }
    };
    (flash == null ? void 0 : flash.message) && mostrar2();
  }, [flash]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: "Registro Huespede",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Registro huespede" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsx("div", { children: mostrar && /* @__PURE__ */ jsx(
            Mensaje,
            {
              mensaje,
              setMostrar,
              setMensaje
            }
          ) }),
          /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
            Link,
            {
              href: route("dashboard"),
              className: "bg-gray-900 text-white rounded-md space-y-2 hover:bg-slate-600\r\n                             px-2 py-2\r\n                 ",
              children: "Regresar"
            }
          ) }),
          /* @__PURE__ */ jsxs("form", { onSubmit: onSubmitHuespede, children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "posadanombre",
                  value: "Nombre Posada"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "text",
                  value: data.posada.nombre,
                  name: "posadanombre",
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: " flex grid-cols-3 space-x-2 mt-2", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "cedula",
                    value: "Cedula"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    type: "text",
                    value: data.cedula,
                    name: "cedula",
                    onChange: (e) => setData("cedula", e.target.value.toUpperCase()),
                    className: "font-bold",
                    placeholder: "cedula comienza con V o E",
                    required: true
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.cedula, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "",
                    value: "Buscar "
                  }
                ),
                /* @__PURE__ */ jsx(
                  PrimaryButton,
                  {
                    name: "btnBuscar",
                    value: data.cedula,
                    onClick: getDataHuespede,
                    children: "Cedula"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "block w-full", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "nombreHuespedes",
                    value: "Nombre Huespede"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    type: "text",
                    value: `${nombreApellido}`,
                    name: "nombrehuespedes",
                    className: "w-full font-bold",
                    disabled: true
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.nombrehuespedes, className: "mt-2" })
              ] })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "mt-2 grid-cols-2 flex   space-x-2  ", children: [
              /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "fechaEntrada",
                    value: "Fecha Entrada"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    type: "date",
                    required: true,
                    name: "fechaEntrada",
                    value: data.fechaEntrada,
                    min: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                    onChange: (e) => setData("fechaEntrada", e.target.value),
                    disabled: true
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.fechaEntrada, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "fechaSalida",
                    value: "Fecha Salida"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    type: "date",
                    required: true,
                    name: "fechaSalida",
                    value: data.fechaSalida,
                    min: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                    onChange: (e) => setData("fechaSalida", e.target.value)
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.fechaSalida, className: "mt-2" })
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "mt-2 flex  space-x-2", children: /* @__PURE__ */ jsxs("div", { className: "w-full", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: "Asignar Cargo Inicial "
                }
              ),
              /* @__PURE__ */ jsxs(
                "select",
                {
                  className: "w-full mt-2 rounded-lg ",
                  name: "precio_id",
                  value: data.precio_id,
                  onChange: (e) => setData("precio_id", e.target.value),
                  children: [
                    /* @__PURE__ */ jsx("option", { children: `|id|Descripcion|Precio $|` }),
                    data.precios.map((item, idx) => /* @__PURE__ */ jsx(
                      "option",
                      {
                        value: item.id,
                        children: `|${item.id}|${item.descripcion}|${item.precio}$|`
                      },
                      item.id
                    ))
                  ]
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.precio_id, className: "mt-2" })
            ] }) }),
            /* @__PURE__ */ jsxs("div", { className: "w-full ", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  htmlFor: "descripcion",
                  value: "Descripcion"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  className: "mt-2 w-full",
                  type: "text",
                  required: true,
                  name: "descripcion",
                  value: data.descripcion,
                  onChange: (e) => setData("descripcion", e.target.value)
                }
              ),
              /* @__PURE__ */ jsx(InputError, { message: errors.descripcion, className: "mt-2" })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "flex mt-2 space-x-2 sm:flex-wrap md:flex-wrap", children: [
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "nrodias",
                    value: "Dias de Estadias"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    className: "mt-2",
                    type: "number",
                    step: "1",
                    required: true,
                    min: "1",
                    name: "nrodias",
                    value: data.nrodias,
                    disabled: true,
                    onChange: (e) => setData("nrodias", e.target.value)
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.nrodias, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "nropersonas",
                    value: "Nro de Personas"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    className: "mt-2",
                    type: "number",
                    step: "1",
                    required: true,
                    min: "1",
                    name: "nropersonas",
                    value: data.nropersonas,
                    onChange: (e) => setData("nropersonas", e.target.value)
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.nropersonas, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "montoTotal",
                    value: "Total"
                  }
                ),
                /* @__PURE__ */ jsx(
                  TextInput,
                  {
                    className: "mt-2",
                    type: "text",
                    step: "1",
                    required: true,
                    name: "montoTotal",
                    disabled: true,
                    value: data.montoTotal
                  }
                ),
                /* @__PURE__ */ jsx(InputError, { message: errors.montoTotal, className: "mt-2" })
              ] }),
              /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx(
                  InputLabel,
                  {
                    htmlFor: "btnCalcular",
                    value: "Calcular"
                  }
                ),
                /* @__PURE__ */ jsx(
                  PrimaryButton,
                  {
                    className: "mt-2 py-3",
                    onClick: calcularTotal,
                    children: "Calcular"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
              PrimaryButton,
              {
                type: "submit",
                name: "btnSumit",
                disabled: processing,
                children: "Enviar"
              }
            ) })
          ] })
        ] })
      ]
    }
  );
}
export {
  RegistroHuespede as default
};
