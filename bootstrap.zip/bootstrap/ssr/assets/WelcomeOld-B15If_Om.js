import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { Link, Head } from "@inertiajs/react";
function SliderImg() {
  const [currentImage, setCurrentImage] = useState(0);
  const images = [
    "posada_01",
    "posada_02",
    "posada_03",
    "posada_04",
    "posada_05",
    "posada_06",
    "posada_07",
    "posada_08"
  ];
  const url = "/imagenes/posada";
  const extension = "jpg";
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImage((prevImage) => Math.floor(Math.random() * 8));
    }, 3e3);
    return () => clearInterval(interval);
  }, []);
  return /* @__PURE__ */ jsx("div", { className: "mx-auto flex items-center justify-center", children: /* @__PURE__ */ jsx("div", { className: "relative  md:w-96 md:h-80 sm:w-full sm:h-full", children: images.map((image, index) => /* @__PURE__ */ jsx(
    "a",
    {
      href: "https://www.instagram.com/loshumacosposada/",
      target: "_blank",
      children: /* @__PURE__ */ jsx(
        "img",
        {
          src: `${url}/${image}.${extension}`,
          alt: "Imagen",
          className: "absolute w-full h-full object-cover transition-opacity duration-1000",
          style: { opacity: currentImage === index ? 1 : 0 }
        }
      )
    },
    index
  )) }) });
}
function Publicidad() {
  const url = "/imagenes/publicidad";
  const images = ["p1"];
  const extension = ".jpg";
  return /* @__PURE__ */ jsxs("div", { className: "mb-10 text-center", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-center text-amber-800 text-2xl font-bold ", children: "Obten el 20% de Descuento en todas Las Monturas para Lentes  " }),
    /* @__PURE__ */ jsxs("h1", { children: [
      "En las  Tiendas ",
      /* @__PURE__ */ jsx("span", { className: "text-amber-800 text-2xl font-bold", children: "MY OPTIC" }),
      " "
    ] }),
    /* @__PURE__ */ jsx("h1", { children: /* @__PURE__ */ jsxs("span", { children: [
      "Registrate",
      /* @__PURE__ */ jsx("span", { className: "text-red-500 font-bold text-2xl", children: /* @__PURE__ */ jsx(
        Link,
        {
          href: route("contacto.show"),
          children: "Aqui"
        }
      ) }),
      " para participar"
    ] }) }),
    /* @__PURE__ */ jsx("div", { className: "justify-center place-items-center py-2 inline-block", children: /* @__PURE__ */ jsx(
      "a",
      {
        href: "https://www.instagram.com/myopticc/",
        target: "_blank",
        children: /* @__PURE__ */ jsx(
          "img",
          {
            src: `${url}/${images}${extension}`,
            width: "40px",
            height: "40px",
            alt: "Myoptic",
            className: "py-2 hover:object-scale-down"
          }
        )
      }
    ) })
  ] });
}
function Welcome({ auth, laravelVersion = "", phpVersion = "" }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Bienvenidos" }),
    /* @__PURE__ */ jsx("header", { className: "absolute top-0  w-full flex justify-end  -mx-1  mt-2 h-10 bg-green-500   ", children: /* @__PURE__ */ jsx("nav", { children: auth.user ? /* @__PURE__ */ jsx(
      Link,
      {
        href: route("dashboard"),
        className: "",
        children: "Dashboard"
      }
    ) : /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsx(
      Link,
      {
        href: route("login"),
        className: "text-2xl",
        children: "Log in"
      }
    ) }) }) }),
    /* @__PURE__ */ jsxs("div", { className: " flex flex-col  bg-green-200 bg-cover  w-full h-full", children: [
      /* @__PURE__ */ jsx("div", { name: "cuerpo", children: /* @__PURE__ */ jsxs("section", { className: " justify-center py-16 ", children: [
        /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Publicidad, {}) }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(SliderImg, {}) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "text-center mt-4  ", children: /* @__PURE__ */ jsxs("section", { className: "mt-2  text-orange-950", children: [
          /* @__PURE__ */ jsx("h1", { className: "text-2xl", children: "Disponemos de cabañas tradicionales" }),
          /* @__PURE__ */ jsx("p", { className: "text-xl", children: "rodeadas de un hermosos paisaje" })
        ] }) })
      ] }) }),
      /* @__PURE__ */ jsx("div", { name: "footer", children: /* @__PURE__ */ jsxs("footer", { className: "absolute bottom-0 justify-center w-full h-48 bg-green-200 ", children: [
        /* @__PURE__ */ jsxs("div", { className: "text-center ", children: [
          /* @__PURE__ */ jsxs("span", { className: "text-amber-950 font-bold text-xl", children: [
            " ",
            "POSADA LOS HUMACOS"
          ] }),
          /* @__PURE__ */ jsx("p", { children: /* @__PURE__ */ jsx("span", { className: "text-amber-950 font-bold text-xl", children: `Reservaciones:${"+58-0424-3380298"} - email:${"loshumacos1@hotmail.com"} ` }) })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "text-center mt-2 font-bold bg-green-500", children: /* @__PURE__ */ jsx("p", { children: `Sistema desarrollado por: ${"Freddy Sierralta"} Email:${"sierralta.freddy@gmail.com"} Phone:${"+58-412-3138606"}` }) })
      ] }) })
    ] })
  ] });
}
export {
  Welcome as default
};
