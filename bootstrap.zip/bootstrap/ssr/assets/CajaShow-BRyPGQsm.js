import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { P as Pagination } from "./Pagination-DLE3c5Ab.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { f as fechaFormato_dmy } from "./help-CPaU3KEz.js";
import { useState, useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function CajaShow({ fechaInicial, flash, fechaFinal, auth, pagos = null, totalGeneral = 0 }) {
  var _a;
  const [showData, setShowData] = useState(false);
  const { data, setData, errors, processing, get } = useForm({
    fechaInicial,
    fechaFinal,
    pagos
  });
  let formatN = new Intl.NumberFormat("de-DE", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const totalAbonoReduce = (data2) => {
    const total = data2.reduce((total2, item) => total2 + parseFloat(item.monto), 0);
    return total;
  };
  const onSubmit = (e) => {
    e.preventDefault();
    try {
      get(route("cajamovimientopagos.get", {
        fechainicial: data.fechaInicial,
        fechafinal: data.fechaFinal
      }));
    } catch (error) {
      console.log("Error al recibir la data", error);
    }
  };
  useEffect(() => {
    var _a2;
    if (((_a2 = data.pagos) == null ? void 0 : _a2.data.length) > 0) {
      setShowData(true);
    }
  }, [data.pagos]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: "Caja ",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Caja" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
            Link,
            {
              className: "bg-slate-500 rounded-lg gap-2 text-white px-4 py-2 items-center",
              href: route("dashboard"),
              children: "Regresar"
            }
          ) }),
          /* @__PURE__ */ jsxs(
            "form",
            {
              name: "frmsubmit",
              onSubmit,
              children: [
                /* @__PURE__ */ jsxs("div", { className: "flex space-x-4", children: [
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx(
                      InputLabel,
                      {
                        htmlFor: "fechaInicial",
                        value: "Fecha Inicial"
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      TextInput,
                      {
                        type: "date",
                        value: data.fechaInicial,
                        name: "fechaInicial",
                        onChange: (e) => setData("fechaInicial", e.target.value),
                        required: true
                      }
                    )
                  ] }),
                  /* @__PURE__ */ jsxs("div", { children: [
                    /* @__PURE__ */ jsx(
                      InputLabel,
                      {
                        htmlFor: "fechaInicial",
                        value: "Fecha Final"
                      }
                    ),
                    /* @__PURE__ */ jsx(
                      TextInput,
                      {
                        type: "date",
                        value: data.fechaFinal,
                        name: "fechaFinal",
                        onChange: (e) => setData("fechaFinal", e.target.value),
                        required: true
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  showData && /* @__PURE__ */ jsxs(Fragment, { children: [
                    /* @__PURE__ */ jsxs("table", { className: "table-auto w-full border border-green-400 py-4 mt-4", children: [
                      /* @__PURE__ */ jsx("thead", { className: "border-collapse ", children: /* @__PURE__ */ jsxs("tr", { children: [
                        /* @__PURE__ */ jsx("th", { className: "border border-green-200 py-2 ", children: "Item" }),
                        /* @__PURE__ */ jsx("th", { className: "border border-green-200 py-2 ", children: "Forma Pago" }),
                        /* @__PURE__ */ jsx("th", { className: "border border-green-200 py-2 ", children: "Fecha" }),
                        /* @__PURE__ */ jsx("th", { className: "border border-green-200 py-2 ", children: "Monto" })
                      ] }) }),
                      /* @__PURE__ */ jsx("tbody", { children: data.pagos != null ? (_a = data.pagos) == null ? void 0 : _a.data.map(
                        (item, idx) => /* @__PURE__ */ jsxs(
                          "tr",
                          {
                            className: "border-collapse ",
                            children: [
                              /* @__PURE__ */ jsx("td", { className: "border border-green-200 py-2 text-center", children: item.id }),
                              /* @__PURE__ */ jsxs("td", { className: "border border-green-200 py-2 text-center", children: [
                                " ",
                                item.hnombre,
                                ". ",
                                item.hapellidos,
                                "- ",
                                item.pnombre,
                                "/",
                                item.nombre
                              ] }),
                              /* @__PURE__ */ jsx("td", { className: "border border-green-200 py-2 text-center", children: ` ${fechaFormato_dmy(item.fechapago)}` }),
                              /* @__PURE__ */ jsx("td", { className: "border border-green-200 py-2 text-center", children: formatN.format(item.monto) })
                            ]
                          },
                          idx
                        )
                      ) : /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: "4", children: "No hay Data" }) }) }) }),
                      /* @__PURE__ */ jsx("tfoot", { children: showData && /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: 4, children: /* @__PURE__ */ jsx("div", { className: "justify-end flex w-full px-2 ", children: /* @__PURE__ */ jsxs("div", { children: [
                        /* @__PURE__ */ jsxs("p", { className: "font-bold  ", children: [
                          "Sub Total pagina:",
                          formatN.format(totalAbonoReduce(data.pagos.data))
                        ] }),
                        /* @__PURE__ */ jsxs("p", { className: "font-bold  ", children: [
                          "Total Caja:",
                          formatN.format(parseFloat(totalGeneral))
                        ] })
                      ] }) }) }) }) })
                    ] }),
                    /* @__PURE__ */ jsx("div", { className: "py-4", children: /* @__PURE__ */ jsx(Pagination, { links: data.pagos.links }) })
                  ] }),
                  !showData && /* @__PURE__ */ jsx("div", { className: "py-2 ", children: /* @__PURE__ */ jsx("p", { className: "font-bold ", children: "No hay data.En el rango de fecha.haga la consulta" }) })
                ] }),
                /* @__PURE__ */ jsxs("div", { className: "py-4", children: [
                  /* @__PURE__ */ jsx(
                    PrimaryButton,
                    {
                      disabled: processing,
                      children: "Consultar"
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    "a",
                    {
                      href: route("repo.04", {
                        fechainicial: data.fechaInicial,
                        fechafinal: data.fechaFinal
                      }),
                      className: "bg-green-400 py-2 rounded-md ml-2 px-2 hover:bg-slate-400 ",
                      children: "Imprimir Reporte"
                    }
                  )
                ] })
              ]
            }
          )
        ] })
      ]
    }
  );
}
export {
  CajaShow as default
};
