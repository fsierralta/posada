import { jsx } from "react/jsx-runtime";
import { useEffect } from "react";
function Mensaje({ mensaje, setMostrar = () => {
}, setMensaje = () => {
} }) {
  useEffect(() => {
    const mostrar = () => {
      setTimeout(() => {
        setMensaje("");
        setMostrar(false);
      }, 3e3);
    };
    mostrar();
  }, [mensaje]);
  return /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("span", { className: "bg-red-500 rounded-lg  text-2xl block w-full mt-2 mb-2", children: mensaje }) });
}
export {
  Mensaje as M
};
