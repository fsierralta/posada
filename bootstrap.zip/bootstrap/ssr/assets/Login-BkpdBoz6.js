import { jsx, jsxs } from "react/jsx-runtime";
import { G as Guest } from "./GuestLayout-Dq2bCslE.js";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { useForm, Head, Link } from "@inertiajs/react";
import axios from "axios";
import { M as Mensaje } from "./Mensaje-DW7XXhCF.js";
import { useState, useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
function Checkbox({ className = "", ...props }) {
  return /* @__PURE__ */ jsx(
    "input",
    {
      ...props,
      type: "checkbox",
      className: "rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500 " + className
    }
  );
}
function Login({ status, flash, canResetPassword }) {
  const [mostrar, setMostrarMessage] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const { data, setData, post, processing, errors, reset } = useForm({
    email: "",
    password: "",
    remember: false,
    verificationcode: ""
  });
  const submit = (e) => {
    e.preventDefault();
    post(route("login"), {
      onFinish: () => reset("password", "verificationcode")
    });
  };
  const getCode = async (e) => {
    e.preventDefault();
    let response = await axios.get(route("codeverification.get", data));
    if (response.status === 200) {
      setMensaje(response.data.message);
      setMostrarMessage(true);
    } else {
      setMensaje(response.data.message);
      setMostrarMessage(true);
    }
  };
  useEffect(() => {
    const mostrar2 = () => {
      setMensaje(flash.message);
      setMostrarMessage(true);
      flash.message = null;
    };
    (flash == null ? void 0 : flash.message) && mostrar2();
  }, [flash.message]);
  return /* @__PURE__ */ jsxs(Guest, { children: [
    /* @__PURE__ */ jsx(Head, { title: "Log in" }),
    status && /* @__PURE__ */ jsx("div", { className: "mb-4 font-medium text-sm text-green-600", children: status }),
    /* @__PURE__ */ jsx("div", { className: "w-full h-6 my-6", children: mostrar ? /* @__PURE__ */ jsx(
      Mensaje,
      {
        mensaje,
        setMostrar: setMostrarMessage,
        setMensaje
      }
    ) : /* @__PURE__ */ jsx("h1", { className: "bg-green-500 rounded-lg  text-2xl block w-full my-4", children: "Solicite su codigo de acceso" }) }),
    /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "email", value: "Email" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "email",
            type: "email",
            name: "email",
            value: data.email,
            className: "mt-1 block w-full",
            autoComplete: "username",
            isFocused: true,
            onChange: (e) => setData("email", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.email, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-4", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "password", value: "Password" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "password",
            type: "password",
            name: "password",
            value: data.password,
            className: "mt-1 block w-full",
            autoComplete: "current-password",
            onChange: (e) => setData("password", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.password, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mt-4", children: [
        /* @__PURE__ */ jsx(InputLabel, { htmlFor: "verificationcode", value: "Codigo" }),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            id: "verificationcode",
            type: "text",
            name: "verificationcode",
            value: data.verificationcode,
            className: "mt-1 block w-full",
            placeholder: "Escribir codigo solicitado",
            onChange: (e) => setData("verificationcode", e.target.value)
          }
        ),
        /* @__PURE__ */ jsx(InputError, { message: errors.verificationcode, className: "mt-2" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "block mt-4", children: /* @__PURE__ */ jsxs("label", { className: "flex items-center", children: [
        /* @__PURE__ */ jsx(
          Checkbox,
          {
            name: "remember",
            checked: data.remember,
            onChange: (e) => setData("remember", e.target.checked)
          }
        ),
        /* @__PURE__ */ jsx("span", { className: "ms-2 text-sm text-gray-600", children: "Remember me" })
      ] }) }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-end mt-4", children: [
        canResetPassword && /* @__PURE__ */ jsx(
          Link,
          {
            href: route("password.request"),
            className: "underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500",
            children: "Olvido  password?"
          }
        ),
        /* @__PURE__ */ jsx(PrimaryButton, { className: "ms-4", disabled: processing, children: "Log in" }),
        /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "ms-4 bg-green-400",
            name: "btncode",
            value: "getcode",
            disabled: processing,
            onClick: getCode,
            children: "Codigo"
          }
        )
      ] })
    ] })
  ] });
}
export {
  Login as default
};
