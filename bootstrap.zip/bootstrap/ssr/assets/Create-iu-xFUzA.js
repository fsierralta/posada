import { jsx, jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { useForm, Head, router } from "@inertiajs/react";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Create({ auth, flash }) {
  useState(true);
  const { data, setData, processing, errors, reset, post } = useForm({
    nombre: "",
    capacidad: 0,
    descripcion: ""
  });
  const submit = (e) => {
    console.log("enviando");
    e.preventDefault();
    post(route("posada.store"), data, {
      onBefore: () => confirm("Desea enviar"),
      onError: (error) => console.log(error)
    });
  };
  const onBack = (e) => {
    e.preventDefault();
    router.get(route("posada.get"));
  };
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: "Create",
      children: /* @__PURE__ */ jsxs(MainHtml, { children: [
        /* @__PURE__ */ jsx(Head, { title: "Create" }),
        /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "bg-blue-600 ",
            onClick: (e) => onBack(e),
            children: "Regresar"
          }
        ) }),
        /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "nombre",
                value: "Nombre"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "nombre",
                className: "mt-1 block w-full",
                value: data.nombre,
                autoComplete: "nombre",
                isFocused: true,
                onChange: (e) => setData("nombre", e.target.value),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.nombre, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "descripcion",
                value: "Descripción",
                required: true,
                className: "mt-2"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "descripcion",
                className: "mt-1 block w-full",
                value: data.descripcion,
                autoComplete: "descripcion",
                onChange: (e) => setData("descripcion", e.target.value),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.descripcion, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "capacidad",
                value: "Capacidad",
                required: true,
                className: "mt-2"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "capacidad",
                type: "number",
                min: 1,
                max: 100,
                className: "mt-1 block w-full",
                value: data.capacidad,
                onChange: (e) => setData("capacidad", e.target.value),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.capacidad, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              disabled: processing,
              children: "Enviar"
            }
          ) })
        ] })
      ] })
    }
  );
}
export {
  Create as default
};
