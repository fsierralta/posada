import { jsxs, jsx } from "react/jsx-runtime";
import { Tabs, TabList, Tab, TabPanel } from "react-tabs";
import RegistroHuespede from "./RegistroHuespede-Dhm1Rc-3.js";
import "./InputError-cRVTeK4i.js";
import "./InputLabel-uXgJWz9w.js";
import "./MainHtml-LqzwaCWZ.js";
import "./Mensaje-DW7XXhCF.js";
import "react";
import "./PrimaryButton-C-TDjBGq.js";
import "./TextInput-Dmygz_uX.js";
import "./AuthenticatedLayout-C4CvgoUh.js";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@inertiajs/react";
import "@headlessui/react";
import "axios";
const TabsHuespedeConAcompanante = ({ auth, flash, dataRegistro }) => /* @__PURE__ */ jsxs(Tabs, { children: [
  /* @__PURE__ */ jsxs(TabList, { children: [
    /* @__PURE__ */ jsx(Tab, { children: "Title 1" }),
    /* @__PURE__ */ jsx(Tab, { children: "Title 2" })
  ] }),
  /* @__PURE__ */ jsx(TabPanel, { children: /* @__PURE__ */ jsx(
    RegistroHuespede,
    {
      auth,
      flash,
      dataRegistro
    }
  ) }),
  /* @__PURE__ */ jsx(TabPanel, { children: /* @__PURE__ */ jsx("h2", { children: "Any content 2" }) })
] });
export {
  TabsHuespedeConAcompanante as default
};
