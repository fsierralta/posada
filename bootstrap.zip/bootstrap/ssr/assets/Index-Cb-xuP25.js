import { jsxs, jsx } from "react/jsx-runtime";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { Head, router } from "@inertiajs/react";
import { P as Pagination } from "./Pagination-DLE3c5Ab.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { S as SecondaryButton } from "./SecondaryButton-BQS06wJz.js";
import { useEffect } from "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Index({ auth, data, flash }) {
  const { data: dataPosada, links } = data;
  const editaritem = (e) => {
    e.preventDefault();
    let id = e.target.value;
    console.log(e.target.value);
    router.get(route("posada.edit", id));
  };
  let alertaclass = "";
  const createItem = (e) => {
    e.preventDefault();
    router.get(route("posada.create"));
  };
  const destroyItem = (e) => {
    e.preventDefault();
    let id = e.target.value;
    router.delete(route("posada.destroy", id), {
      onBefore: () => window.confirm("Desea eliminar este item"),
      onSuccess: () => console.log(flash == null ? void 0 : flash.message),
      onError: (error) => {
        console.log(error);
      }
    });
  };
  useEffect(() => {
    if (flash.message) {
      let span = document.querySelector("#mensaje");
      alertaclass = "bg-red-500 rounded-lg block w-full space-y-2 text-2xl";
      span.textContent = `${flash.message} `;
      span.className = alertaclass;
      setTimeout(() => {
        span.textContent = "";
        flash.message = "";
      }, 3e3);
    }
  }, [flash]);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: "Catalogo cabañas",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Cabaña" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsx("div", { className: "mt-2 my-2", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              onClick: (e) => createItem(e),
              children: "Crear item"
            }
          ) }),
          (flash == null ? void 0 : flash.message) && /* @__PURE__ */ jsx("div", { id: "alerta", className: `mt-2  mb-2`, children: /* @__PURE__ */ jsx("span", { id: "mensaje", className: `${alertaclass}` }) }),
          dataPosada.length > 0 ? /* @__PURE__ */ jsxs("table", { className: "table-auto  border border-green-700\r\n                            border-separate border-spacing-2 w-full", children: [
            /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "bg-green-300", children: [
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg  ", children: "Id" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Nombre" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Capacidad" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Descripción" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Editar" }),
              /* @__PURE__ */ jsx("th", { className: "border border-green-700 rounded-lg", children: "Eliminar" })
            ] }) }),
            /* @__PURE__ */ jsx("tbody", { children: dataPosada.map((item, idx) => /* @__PURE__ */ jsxs("tr", { children: [
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.id }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.nombre }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.capacidad }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: item.descripcion }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: /* @__PURE__ */ jsx(
                PrimaryButton,
                {
                  name: "btnEditar",
                  value: item.id,
                  onClick: (e) => editaritem(e),
                  children: "Editar"
                }
              ) }),
              /* @__PURE__ */ jsx("td", { className: "border border-green-700", children: /* @__PURE__ */ jsx(
                SecondaryButton,
                {
                  name: "btnDestroy",
                  value: item.id,
                  className: "bg-red-500",
                  onClick: (e) => destroyItem(e),
                  children: "Eliminar"
                }
              ) })
            ] }, idx)) })
          ] }) : /* @__PURE__ */ jsx("h1", { children: "No hay Data" }),
          /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(Pagination, { links }) })
        ] })
      ]
    }
  );
}
export {
  Index as default
};
