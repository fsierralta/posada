import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { useForm, Head, router } from "@inertiajs/react";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { I as InputError } from "./InputError-cRVTeK4i.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function Edit({ auth, flash, dataEdit }) {
  const { data, setData, processing, errors, reset, post, put } = useForm({
    precio: dataEdit.precio,
    descripcion: dataEdit.descripcion,
    tipo: dataEdit.tipo,
    id: dataEdit.id
  });
  const submit = (e) => {
    console.log("enviando");
    e.preventDefault();
    put(route("precio.put", data), {
      onBefore: () => window.confirm("Desea enviar"),
      onError: (error) => console.log(error)
    });
  };
  const onBack = (e) => {
    e.preventDefault();
    router.get(route("precio.get"));
  };
  return /* @__PURE__ */ jsx(
    Authenticated,
    {
      user: auth.user,
      header: "Edit",
      children: /* @__PURE__ */ jsxs(MainHtml, { children: [
        /* @__PURE__ */ jsx(Head, { title: "Edit Precio" }),
        /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
          PrimaryButton,
          {
            className: "bg-blue-600 ",
            onClick: (e) => onBack(e),
            children: "Regresar"
          }
        ) }),
        /* @__PURE__ */ jsxs("form", { onSubmit: submit, children: [
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "id",
                value: "Id Item"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "id",
                className: "mt-1 block w-full",
                value: data.id,
                disabled: true
              }
            )
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "precio",
                value: "Precio $"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "precio",
                className: "mt-1 block w-full",
                value: data.precio,
                autoComplete: "precio",
                isFocused: true,
                type: "number",
                min: "1",
                max: "9999",
                step: "0.01",
                onChange: (e) => setData("precio", e.target.value),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.precio, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "descripcion",
                value: "Descripción",
                required: true,
                className: "mt-2"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                id: "descripcion",
                className: "mt-1 block w-full",
                value: data.descripcion,
                autoComplete: "descripcion",
                onChange: (e) => setData("descripcion", e.target.value),
                required: true
              }
            ),
            /* @__PURE__ */ jsx(InputError, { message: errors.descripcion, className: "mt-2" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "mt-4", children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              disabled: processing,
              children: "Enviar"
            }
          ) })
        ] })
      ] })
    }
  );
}
export {
  Edit as default
};
