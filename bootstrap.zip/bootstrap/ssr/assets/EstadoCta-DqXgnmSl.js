import { jsxs, jsx } from "react/jsx-runtime";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { Head, Link } from "@inertiajs/react";
import "react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
import "@headlessui/react";
function EstadoCta({ auth, flash, dataEstadoCuenta }) {
  const { fichaRegistro, posada, detalleCargo, detalleAbono } = dataEstadoCuenta;
  const { huespede } = fichaRegistro;
  let formatN = new Intl.NumberFormat("de-DE", {
    style: "decimal",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
  const totalCargo = detalleCargo.reduce((totalItem, item) => {
    return totalItem + parseFloat(item.totalitem);
  }, 0);
  let totalAbono = detalleAbono.reduce((totalItem, item) => {
    return totalItem + parseFloat(item.monto);
  }, 0);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: "Estado de Cuenta",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Estado de Cuenta" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2", children: [
            /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
              Link,
              {
                href: route("dashboard"),
                className: "bg-gray-800 text-white py-2 px-2 rounded-md hover:bg-slate-500",
                children: "Regresar"
              }
            ) }),
            /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
              "a",
              {
                href: route("repo.02", posada.id),
                target: "_blank",
                className: "bg-blue-900 px-4 py-2 text-white rounded-lg hover:bg-slate-300",
                children: "Imprimir"
              }
            ) })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "flex space-x-2 py-4 ", children: /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx(
              InputLabel,
              {
                htmlFor: "posada",
                value: "Cabaña"
              }
            ),
            /* @__PURE__ */ jsx(
              TextInput,
              {
                name: "posada",
                value: posada.nombre,
                disabled: true
              }
            )
          ] }) }),
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2 mt-2", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: "Ficha Registro"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  value: fichaRegistro.nroficha,
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "w-full ", children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: "Huespede"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  value: `${huespede.nombre} ${huespede.apellidos}`,
                  disabled: true,
                  className: "w-full"
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: "Cedula"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  value: `${huespede.nacionalidad}${huespede.cedula}`,
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: "Entrada"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  type: "date",
                  value: fichaRegistro.fechaEntrada,
                  disabled: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                InputLabel,
                {
                  value: "Salidad"
                }
              ),
              /* @__PURE__ */ jsx(
                TextInput,
                {
                  value: fichaRegistro.fechaSalida,
                  type: "date",
                  disabled: true
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "flex space-x-2 py-2 overflow-auto h-96", children: [
            /* @__PURE__ */ jsxs("div", { className: "bg-green-300 rounded-lg w-full  h-96 overflow-auto ", children: [
              /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl", children: "Cargos" }),
              /* @__PURE__ */ jsx("div", { className: "py-2", children: /* @__PURE__ */ jsx("hr", {}) }),
              detalleCargo.map((item, idx) => /* @__PURE__ */ jsx(
                "li",
                {
                  children: /* @__PURE__ */ jsxs("span", { children: [
                    `|Nro:${item.id}`,
                    " Fecha:",
                    /* @__PURE__ */ jsx(
                      "input",
                      {
                        type: "date",
                        value: item.fecharegistro,
                        disabled: true,
                        className: "rounded-lg  text-sm bg-green-300 border-none"
                      }
                    ),
                    /* @__PURE__ */ jsx("br", {}),
                    `|${item.pvpdescripcion} |$:${item.precio} 
                                                    |NroPerso:${item.nropersonas} |Cantidad:${item.cantidad}
                                                    |Total:${item.totalitem}|
                                    `
                  ] })
                },
                `carg${idx}`
              )),
              /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("hr", {}) }),
              /* @__PURE__ */ jsx("h1", { className: "", children: /* @__PURE__ */ jsx("span", { className: "text-green-900 font-bold text-xl", children: `Total Cargos:${formatN.format(totalCargo)}` }) })
            ] }),
            /* @__PURE__ */ jsxs("div", { className: "bg-blue-300 rounded-lg w-full h-96 overflow-auto ", children: [
              /* @__PURE__ */ jsx("h1", { className: "font-bold text-xl ", children: "Abonos" }),
              /* @__PURE__ */ jsx("div", { className: "py-2", children: /* @__PURE__ */ jsx("hr", {}) }),
              detalleAbono.map((item, idx) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("span", { children: [
                `|Nro:${item.id}| Fecha:`,
                "  ",
                /* @__PURE__ */ jsx(
                  "input",
                  {
                    value: item.fechapago,
                    type: "date",
                    className: "border-none bg-blue-300",
                    disabled: true
                  }
                ),
                /* @__PURE__ */ jsx("br", {}),
                `| Referencia:${item.referencia}|Forma:${item.fpagonombre}
                                |Observación:${item.observacion}| Monto:${item.monto}$|`
              ] }) }, `abn${idx}`)),
              /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("hr", {}) }),
              /* @__PURE__ */ jsx("h1", { className: "w-full block justify-end content-end", children: /* @__PURE__ */ jsx(
                "span",
                {
                  className: "text-blue-900 font-bold text-xl justify-end \r\n                                            w-full bock",
                  children: `Total  Abonos:${formatN.format(totalAbono)}`
                }
              ) })
            ] })
          ] }),
          /* @__PURE__ */ jsx("div", { children: totalCargo - totalAbono == 0 ? /* @__PURE__ */ jsx("span", { className: "bg-green-400 w-full block rounded-lg text-xl mt-2 ", children: "Saldos Encontrados" }) : /* @__PURE__ */ jsxs("span", { className: "bg-red-400 w-full block rounded-lg text-xl mt-2  ", children: [
            "Hay una Diferencia:Revises:",
            formatN.format(totalCargo - totalAbono)
          ] }) })
        ] })
      ]
    }
  );
}
export {
  EstadoCta as default
};
