import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import { I as InputLabel } from "./InputLabel-uXgJWz9w.js";
import { T as TextInput } from "./TextInput-Dmygz_uX.js";
import { M as MainHtml } from "./MainHtml-LqzwaCWZ.js";
import { M as Modal } from "./Modal-Vm18LNJq.js";
import { P as PrimaryButton } from "./PrimaryButton-C-TDjBGq.js";
import { S as SecondaryButton } from "./SecondaryButton-BQS06wJz.js";
import { A as Authenticated } from "./AuthenticatedLayout-C4CvgoUh.js";
import { useForm, Head, Link } from "@inertiajs/react";
import { useState } from "react";
import "@headlessui/react";
import "./ApplicationLogo-CLvzS28V.js";
import "./MenuDatosBasicos-BvFUTzRp.js";
function DatoHuespedes({ posada, huespede, fichaRegistroH }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx(
        InputLabel,
        {
          htmlFor: "posadanombre",
          value: "Nombre Posada"
        }
      ),
      /* @__PURE__ */ jsx(
        TextInput,
        {
          type: "text",
          defaultValue: posada.nombre,
          name: "posadanombre",
          disabled: true
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: " flex grid-cols-3 space-x-2 mt-2", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "cedula",
            value: "Cedula"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            type: "text",
            defaultValue: `${huespede.nacionalidad}${huespede.cedula}`,
            name: "cedula",
            className: "font-bold",
            disabled: true
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "block w-full", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "nroficha",
            value: "Nro Ficha"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            type: "text",
            defaultValue: `${fichaRegistroH.nroficha}`,
            name: "nroficha",
            className: "w-full font-bold",
            disabled: true
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "block w-full", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "nombreHuespedes",
            value: "Nombre Huespede"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            type: "text",
            defaultValue: `${huespede.nombre}${huespede.apellidos}`,
            name: "nombrehuespedes",
            className: "w-full font-bold",
            disabled: true
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mt-2 flex   space-x-2  ", children: [
      /* @__PURE__ */ jsxs("div", { className: "", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "fechaEntrada",
            value: "Fecha Entrada"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            type: "date",
            required: true,
            name: "fechaEntrada",
            defaultValue: fichaRegistroH.fechaEntrada,
            disabled: true
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "", children: [
        /* @__PURE__ */ jsx(
          InputLabel,
          {
            htmlFor: "fechaSalida",
            value: "Fecha Salida"
          }
        ),
        /* @__PURE__ */ jsx(
          TextInput,
          {
            type: "date",
            required: true,
            name: "fechaSalida",
            defaultValue: `${fichaRegistroH.fechaSalida}`,
            disabled: true
          }
        )
      ] })
    ] })
  ] });
}
function Factura({ auth, flash, datahuespede }) {
  const [show, setShow] = useState(false);
  const { posada, huespede } = datahuespede.ficharegistro;
  const { ficharegistro } = datahuespede;
  const { data, setData, patch, processing } = useForm({
    id: posada.id
  });
  const darDeAlta = (e) => {
    e.preventDefault();
    patch(route("dardealta.patch", posada.id), {
      onError: (error) => console.log(error),
      onSuccess: () => oncloseModal()
    });
  };
  const oncloseModal = () => {
    setShow(false);
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      user: auth.user,
      header: "Nota de Factura",
      children: [
        /* @__PURE__ */ jsx(Head, { title: "NotaFactura" }),
        /* @__PURE__ */ jsxs(MainHtml, { children: [
          /* @__PURE__ */ jsxs("div", { className: "flex  space-x-2 ", children: [
            /* @__PURE__ */ jsx("div", { className: "mb-2", children: /* @__PURE__ */ jsx(
              Link,
              {
                className: "bg-slate-500 rounded-lg gap-2 text-white px-4 py-2 items-center",
                href: route("dashboard"),
                children: "Regresar"
              }
            ) }),
            /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
              "a",
              {
                href: route("repo.03", posada.id),
                target: "_blank",
                className: "bg-green-500 rounded-lg gap-2 text-white px-4 py-2 items-center",
                children: "Imprimir Nota factura"
              }
            ) })
          ] }),
          show && /* @__PURE__ */ jsx(
            Modal,
            {
              show,
              onClose: oncloseModal,
              children: /* @__PURE__ */ jsx("form", { onSubmit: darDeAlta, children: /* @__PURE__ */ jsxs("div", { children: [
                /* @__PURE__ */ jsx("p", { className: "text-red-600 text-xl font-bold text-center py-4", children: "Debe haber impreso la Nota de factura, Asegurese de haber la imprimido?" }),
                /* @__PURE__ */ jsxs("div", { className: "flex px-2 py-4 space-x-4 justify-center", children: [
                  /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
                    PrimaryButton,
                    {
                      name: "btndarDeAlta",
                      onClick: oncloseModal,
                      children: "Cancelar "
                    }
                  ) }),
                  /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
                    SecondaryButton,
                    {
                      name: "btndarDeAlta",
                      disabled: processing,
                      type: "submit",
                      children: "Dar de Alta"
                    }
                  ) })
                ] })
              ] }) })
            }
          ),
          /* @__PURE__ */ jsx(
            DatoHuespedes,
            {
              posada,
              huespede,
              fichaRegistroH: ficharegistro
            }
          ),
          /* @__PURE__ */ jsx("div", { className: "flex mt-4", children: /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(
            PrimaryButton,
            {
              name: "btndarDeAlta",
              onClick: () => setShow(true),
              children: "Dar de alta"
            }
          ) }) })
        ] })
      ]
    }
  );
}
export {
  Factura as default
};
